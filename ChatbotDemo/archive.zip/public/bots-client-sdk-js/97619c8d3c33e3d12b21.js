webpackJsonp([106],{805:function(e,M,Y){"use strict";Object.defineProperty(M,"__esModule",{value:!0});var a=Y(192),t=function(e){return e&&e.__esModule?e:{default:e}}(a),L=(0,t.default)({LT:"h:mm aa",LTS:"h:mm:ss aa",L:"MM/DD/YYYY",LL:"MMMM D YYYY",LLL:"MMMM D YYYY h:mm aa",LLLL:"dddd, MMMM D YYYY h:mm aa"});M.default=L,e.exports=M.default}});
//# sourceMappingURL=97619c8d3c33e3d12b21.js.map
