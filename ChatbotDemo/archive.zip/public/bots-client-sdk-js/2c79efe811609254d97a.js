webpackJsonp([70],{842:function(e,t,d){"use strict";function r(e,t,d,r){return o[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=r;var o={lastWeek:"[förra] dddd[en kl.] LT",yesterday:"[igår kl.] LT",today:"[idag kl.] LT",tomorrow:"[imorgon kl.] LT",nextWeek:"dddd [kl.] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=2c79efe811609254d97a.js.map
