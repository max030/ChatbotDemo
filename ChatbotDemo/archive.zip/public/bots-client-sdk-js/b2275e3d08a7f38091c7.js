webpackJsonp([190],{721:function(e,t,d){"use strict";function r(e,t,d,r){return o[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=r;var o={lastWeek:"[sidste] dddd [kl.] LT",yesterday:"[i går kl.] LT",today:"[i dag kl.] LT",tomorrow:"[i morgen kl.] LT",nextWeek:"[på] dddd [kl.] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=b2275e3d08a7f38091c7.js.map
