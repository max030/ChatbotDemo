webpackJsonp([153],{764:function(e,d,t){"use strict";function r(e,d,t,r){return o[e]}Object.defineProperty(d,"__esModule",{value:!0}),d.default=r;var o={lastWeek:"[hier] dddd [à] LT",yesterday:"[hier à] LT",today:"[aujourd’hui à] LT",tomorrow:"[demain à] LT",nextWeek:"dddd [à] LT",other:"L"};e.exports=d.default}});
//# sourceMappingURL=15152c90f63a452bc0d2.js.map
