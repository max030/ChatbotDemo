webpackJsonp([191],{707:function(e,M,Y){"use strict";Object.defineProperty(M,"__esModule",{value:!0});var d=Y(189),t=function(e){return e&&e.__esModule?e:{default:e}}(d),L=(0,t.default)({LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY HH:mm",LLLL:"dddd [d.] D. MMMM YYYY [kl.] HH:mm"});M.default=L,e.exports=M.default}});
//# sourceMappingURL=e5ea16377eb3e6294fee.js.map
