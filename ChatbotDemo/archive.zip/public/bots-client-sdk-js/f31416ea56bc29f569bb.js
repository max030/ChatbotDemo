webpackJsonp([81],{830:function(e,M,Y){"use strict";Object.defineProperty(M,"__esModule",{value:!0});var t=Y(192),L=function(e){return e&&e.__esModule?e:{default:e}}(t),d=(0,L.default)({LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY г.",LLL:"D MMMM YYYY г., HH:mm",LLLL:"dddd, D MMMM YYYY г., HH:mm"});M.default=d,e.exports=M.default}});
//# sourceMappingURL=f31416ea56bc29f569bb.js.map
