webpackJsonp([173],{725:function(e,t,d){"use strict";function a(e,t,d,a){return o[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=a;var o={lastWeek:"[pasinta] dddd [je] LT",yesterday:"[hieraŭ je] LT",today:"[hodiaŭ je] LT",tomorrow:"[morgaŭ je] LT",nextWeek:"dddd [je] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=d58f0f80bf7dad4cfdb5.js.map
